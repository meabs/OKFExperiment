"""Client code for the pricing service, which is a separate repository that runs elsewhere.

`http` is an httpx-style client already bound to the service's base URL, so call it with paths: `http.get("/orders")`.
"""
import time


class OrderError(Exception):
    """Any other failure to place an order."""


class UnknownSku(OrderError):
    """The order named a SKU the catalogue does not have."""


class KeyConflict(OrderError):
    """An idempotency key was reused for a different order."""


def fetch_all_orders(http):
    out, cursor = [], None
    while True:
        r = http.get("/orders", params={"limit": 50, **({"cursor": cursor} if cursor else {})}).json()
        out += r["orders"]
        cursor = r["next_cursor"]
        if not cursor:
            return out


def place_order(http, items, coupons, key, sleep=time.sleep):
    while True:
        r = http.post("/orders", json={"items": items, "coupons": coupons}, headers={"Idempotency-Key": key})
        if r.status_code == 429:
            sleep(int(r.headers["Retry-After"])); continue
        if r.status_code in (200, 201):
            return r.json()
        if r.status_code == 404: raise UnknownSku(r.text)
        if r.status_code == 409: raise KeyConflict(r.text)
        raise OrderError(r.text)


def preview_total(items, coupons):
    import sys, os
    sys.path.insert(0, os.environ["PRICING_SERVICE"])
    from pricing import rules
    sub = sum(rules.line_total(i["sku"], i["quantity"]) for i in items)
    d, _ = rules.apply_coupons(sub, coupons)
    return d + rules.shipping(d)
